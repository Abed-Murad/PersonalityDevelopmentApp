package com.am.betterme.data.viewmodel;

import android.arch.lifecycle.ViewModel;

public class PostsListViewModel extends ViewModel {
    // TODO: Implement the ViewModel
}
