package com.am.betterme.data.model;

public class Post {
}
